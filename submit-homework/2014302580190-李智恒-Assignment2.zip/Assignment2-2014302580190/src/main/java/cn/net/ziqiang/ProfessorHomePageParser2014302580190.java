package cn.net.ziqiang;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.File;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by Hubert on 15/10/18.
 */
public class ProfessorHomePageParser2014302580190 {

    Document doc;
    Professor2014302580190 professor;

    public ProfessorHomePageParser2014302580190(String filePath) {
        try {
            this.doc = Jsoup.parse(new File(filePath), "GBK", "");
        } catch(IOException e) {
            e.printStackTrace();
        }
        this.professor = new Professor2014302580190();
    }

    public void parseEmail() {
        Pattern pattern = Pattern.compile("\\w+([-+.]\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*");
        Elements elements = doc.getElementsMatchingOwnText(pattern);
        String text = elements.text();
        Matcher matcher = pattern.matcher(text);
        String email = "";
        if (matcher.find()) {
            email = matcher.group();
        }

        this.professor.emailAddress = email;
    }

    public void parsePhoneNumber() {
        Pattern pattern = Pattern.compile("(\\(\\d{3,4}\\)|\\d{3,4}-|\\s)?\\d{8}");
        Elements elements = doc.getElementsMatchingOwnText(pattern);
        Element element = elements.first();
        String text = element.text();
        Matcher matcher = pattern.matcher(text);
        String phoneNumber = "";
        if (matcher.find()) {
            phoneNumber = matcher.group();
        }

        this.professor.phoneNumber = phoneNumber;
    }

    public void parseName() {
        Elements elements = doc.getElementsContainingOwnText("姓名");
        String name = elements.text().substring(4);
        this.professor.name = name;
    }

    public void parseResearchDirection() {
        Elements elements = doc.getElementsContainingOwnText("研究方向");
        Element element = elements.first();
        String researchDirection = element.text().substring(6);
        this.professor.researchDirection = researchDirection;
    }

    public void parseInfo() {
        Elements elements = doc.getElementsByAttributeValue("face", "Arial");
        String text = elements.text();
        this.professor.info = text.substring(8);
    }

    public void outputToTxtFile(String filePath) {
        this.professor.writeProToTxtFile(filePath);
    }





}
