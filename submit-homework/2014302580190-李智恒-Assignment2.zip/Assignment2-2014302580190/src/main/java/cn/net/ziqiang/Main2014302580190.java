package cn.net.ziqiang;

/**
 * Created by Hubert on 15/10/18.
 */
public class Main2014302580190 {
    public static void main(String[] args) {
        ProfessorHomePageParser2014302580190 parser = new ProfessorHomePageParser2014302580190("./Resource/新世纪人才 -武汉大学计算机学院.html");
        parser.parseEmail();
        parser.parsePhoneNumber();
        parser.parseName();
        parser.parseResearchDirection();
        parser.parseInfo();

        String outputPath = "./Output/Professor.txt";
        parser.outputToTxtFile(outputPath);

    }
}
