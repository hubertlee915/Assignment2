package cn.net.ziqiang;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Created by Hubert on 15/10/18.
 */
public class Professor2014302580190 {
    String name;
    String info;
    String researchDirection;
    String emailAddress;
    String phoneNumber;

    public void setName(String name) {
        this.name = name;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public void setResearchDirection(String researchDirection) {
        this.researchDirection = researchDirection;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void writeProToTxtFile(String filePath) {
        File f = new File(filePath);
        BufferedWriter bf = null;
        try {
            bf = new BufferedWriter(new FileWriter(f));
            String proTxtStr = "姓名: " + name + "\n" + "研究方向: " + researchDirection + "\n" + "邮箱: " + emailAddress + "\n" + "电话号码: " + phoneNumber + "\n" + "简介: " + "\n" + info;
            bf.write(proTxtStr);
            bf.flush();
            bf.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                bf.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
}
